/**
 * AgriTwin AI — Ultra-Creative Interactive Digital Twin Frontend Engine
 * Includes:
 *   - Procedural 2D/3D Biome Canvas (Plant growth, root depth, soil strata, weather particles)
 *   - Floating Particle Matrix Background
 *   - AI Multi-Model Inference Engine (RF, SVM, pure NumPy LSTM proxy)
 *   - Scenario Presets (Heatwave, Monsoon, Drought, Flowering)
 *   - Web Audio API Sound Synthesizer
 */

// Global Twin State
const state = {
  activeZone: 2,
  moisture: 24.5,
  temperature: 28.0,
  humidity: 58.0,
  vpd: 1.60,
  rain24h: 1.5,
  gdd: 620,
  stage: "3_Flowering",
  ndvi: 0.76,
  injectStress: false,
  crashSeverity: 12.0,
  soundEnabled: false,
  animTick: 0
};

// Spatial Micro-Plot Profiles
const zones = {
  1: {
    name: "Zone 1: Sandy Loam (West Plot)",
    badge: "Zone 1: Sandy Loam",
    baseMoist: 17.5,
    baseTemp: 29.5,
    baseVpd: 1.95,
    baseNdvi: 0.68,
    soilDesc: "Coarse Sand (22% FC)",
    priority: "HIGH (Fast Drainage)",
    priorityColor: "#d97706",
    soilTone: [100, 75, 40]
  },
  2: {
    name: "Zone 2: Clay Loam (East Plot - Primary)",
    badge: "Zone 2: Clay Loam",
    baseMoist: 26.5,
    baseTemp: 28.0,
    baseVpd: 1.60,
    baseNdvi: 0.78,
    soilDesc: "Clay Loam (34% FC)",
    priority: "NOMINAL",
    priorityColor: "#6ee7b7",
    soilTone: [65, 42, 22]
  },
  3: {
    name: "Zone 3: Lowland Alluvial (South Basin)",
    badge: "Zone 3: Alluvial Basin",
    baseMoist: 34.0,
    baseTemp: 25.5,
    baseVpd: 1.15,
    baseNdvi: 0.82,
    soilDesc: "Alluvial Silt (38% FC)",
    priority: "LOW (Waterlogging Risk)",
    priorityColor: "#0284c7",
    soilTone: [35, 24, 15]
  },
  4: {
    name: "Zone 4: Sun-Exposed Ridge (North Slope)",
    badge: "Zone 4: Ridge",
    baseMoist: 19.5,
    baseTemp: 32.5,
    baseVpd: 2.40,
    baseNdvi: 0.64,
    soilDesc: "Rocky Ridge (28% FC)",
    priority: "URGENT (Solar Heat)",
    priorityColor: "#ef4444",
    soilTone: [90, 50, 25]
  }
};

// --- Web Audio Synthesizer (Zero External Assets) ---
let audioCtx = null;

function initAudio() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
}

function playTone(freq, type = "sine", duration = 0.12, gain = 0.08) {
  if (!state.soundEnabled || !audioCtx) return;
  try {
    const osc = audioCtx.createOscillator();
    const gNode = audioCtx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
    gNode.gain.setValueAtTime(gain, audioCtx.currentTime);
    gNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
    osc.connect(gNode);
    gNode.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch (e) {}
}

function playWaterDrop() {
  playTone(880, "sine", 0.08, 0.05);
  setTimeout(() => playTone(1200, "sine", 0.06, 0.03), 40);
}

// --- Background Neural Particle Animation ---
function setupBgParticles() {
  const canvas = document.getElementById("bg-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  let w = (canvas.width = window.innerWidth);
  let h = (canvas.height = window.innerHeight);

  window.addEventListener("resize", () => {
    w = canvas.width = window.innerWidth;
    h = canvas.height = window.innerHeight;
  });

  const particles = Array.from({ length: 45 }, () => ({
    x: Math.random() * w,
    y: Math.random() * h,
    vx: (Math.random() - 0.5) * 0.4,
    vy: (Math.random() - 0.5) * 0.4,
    r: Math.random() * 2 + 1,
    alpha: Math.random() * 0.4 + 0.1
  }));

  function drawBg() {
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < particles.length; i++) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0) p.x = w;
      if (p.x > w) p.x = 0;
      if (p.y < 0) p.y = h;
      if (p.y > h) p.y = 0;

      ctx.fillStyle = `rgba(16, 185, 129, ${p.alpha})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();

      // Connecting links
      for (let j = i + 1; j < particles.length; j++) {
        const p2 = particles[j];
        const dist = Math.hypot(p.x - p2.x, p.y - p2.y);
        if (dist < 130) {
          ctx.strokeStyle = `rgba(16, 185, 129, ${(1 - dist / 130) * 0.12})`;
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
        }
      }
    }
    requestAnimationFrame(drawBg);
  }
  drawBg();
}

// --- Procedural Biome & Plant Canvas Rendering ---
function setupBiomeCanvas() {
  const canvas = document.getElementById("biome-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);

  const rainDrops = Array.from({ length: 30 }, () => ({
    x: Math.random() * rect.width,
    y: Math.random() * (rect.height * 0.45),
    vy: Math.random() * 4 + 3,
    len: Math.random() * 8 + 6
  }));

  function renderBiome() {
    state.animTick++;
    const w = rect.width;
    const h = rect.height;
    const groundY = h * 0.46;

    ctx.clearRect(0, 0, w, h);

    // 1. Sky & Sun/Heat gradient
    const tempIntensity = Math.min(1.0, Math.max(0.0, (state.temperature - 15) / 30));
    const skyGrad = ctx.createLinearGradient(0, 0, 0, groundY);
    skyGrad.addColorStop(0, `rgb(${Math.round(11 + tempIntensity * 40)}, ${Math.round(34 + (1 - tempIntensity) * 20)}, 22)`);
    skyGrad.addColorStop(1, `rgb(${Math.round(23 + tempIntensity * 30)}, 56, 38)`);
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, w, groundY);

    // Glowing Sun
    const sunX = w * 0.82;
    const sunY = 38;
    const sunGrad = ctx.createRadialGradient(sunX, sunY, 5, sunX, sunY, 35);
    sunGrad.addColorStop(0, `rgba(255, 220, 100, ${0.7 + tempIntensity * 0.3})`);
    sunGrad.addColorStop(1, "rgba(255, 220, 100, 0)");
    ctx.fillStyle = sunGrad;
    ctx.beginPath();
    ctx.arc(sunX, sunY, 35, 0, Math.PI * 2);
    ctx.fill();

    // 2. Rain Animation (if raining)
    if (state.rain24h > 2.0) {
      ctx.strokeStyle = "rgba(147, 197, 253, 0.6)";
      ctx.lineWidth = 1.2;
      rainDrops.forEach(d => {
        d.y += d.vy;
        if (d.y > groundY) d.y = 0;
        ctx.beginPath();
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - 1, d.y + d.len);
        ctx.stroke();
      });
    }

    // 3. Multi-Layer Soil Strata (Topsoil, Root Zone, Deep Subsoil)
    const zInfo = zones[state.activeZone] || zones[2];
    const effMoist = state.moisture - (state.injectStress ? state.crashSeverity : 0);
    const moistRatio = Math.min(1.0, Math.max(0.1, effMoist / 45.0));
    const [tr, tg, tb] = zInfo.soilTone;

    // Topsoil (0-10cm)
    ctx.fillStyle = `rgb(${Math.round(tr + (1 - moistRatio) * 30)}, ${Math.round(tg + (1 - moistRatio) * 20)}, ${Math.round(tb + (1 - moistRatio) * 15)})`;
    ctx.fillRect(0, groundY, w, (h - groundY) * 0.28);

    // Root Zone (10-30cm)
    ctx.fillStyle = `rgb(${Math.round(tr - moistRatio * 20)}, ${Math.round(tg - moistRatio * 15)}, ${Math.round(tb - moistRatio * 10)})`;
    ctx.fillRect(0, groundY + (h - groundY) * 0.28, w, (h - groundY) * 0.42);

    // Deep Subsoil (30-60cm)
    ctx.fillStyle = `rgb(${Math.round(tr * 0.65 - moistRatio * 10)}, ${Math.round(tg * 0.65 - moistRatio * 10)}, ${Math.round(tb * 0.65 - moistRatio * 5)})`;
    ctx.fillRect(0, groundY + (h - groundY) * 0.70, w, (h - groundY) * 0.30);

    // Layer separator lines
    ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, groundY + (h - groundY) * 0.28);
    ctx.lineTo(w, groundY + (h - groundY) * 0.28);
    ctx.moveTo(0, groundY + (h - groundY) * 0.70);
    ctx.lineTo(w, groundY + (h - groundY) * 0.70);
    ctx.stroke();

    // Strata Labels
    ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
    ctx.font = "9px sans-serif";
    ctx.fillText("Topsoil (0-10cm)", 10, groundY + 16);
    ctx.fillText("Active Root Zone (10-30cm)", 10, groundY + (h - groundY) * 0.28 + 16);
    ctx.fillText("Subsoil (30-60cm)", 10, groundY + (h - groundY) * 0.70 + 16);

    // 4. Procedural Animated Crop Plant
    const plantX = w * 0.50;
    const sway = Math.sin(state.animTick * 0.03) * 4;
    const plantHealth = Math.max(0.2, Math.min(1.0, state.ndvi));

    // Stems & Leaves
    ctx.strokeStyle = `rgb(${Math.round(40 + (1 - plantHealth) * 120)}, ${Math.round(160 * plantHealth)}, 50)`;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(plantX, groundY);
    ctx.quadraticCurveTo(plantX + sway * 0.5, groundY - 40, plantX + sway, groundY - 85);
    ctx.stroke();

    // Leaves
    ctx.fillStyle = `rgb(${Math.round(40 + (1 - plantHealth) * 140)}, ${Math.round(180 * plantHealth)}, 60)`;
    [-1, 1].forEach(side => {
      ctx.beginPath();
      ctx.ellipse(plantX + side * 22 + sway * 0.7, groundY - 48, 20, 7, side * 0.4, 0, Math.PI * 2);
      ctx.fill();

      ctx.beginPath();
      ctx.ellipse(plantX + side * 18 + sway * 0.9, groundY - 72, 16, 6, side * 0.35, 0, Math.PI * 2);
      ctx.fill();
    });

    // Golden Flower / Fruit
    if (state.stage.includes("Flowering") || state.stage.includes("GrainFilling") || state.stage.includes("Maturity")) {
      ctx.fillStyle = "#fbbf24";
      ctx.beginPath();
      ctx.arc(plantX + sway, groundY - 92, 9, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#f59e0b";
      ctx.beginPath();
      ctx.arc(plantX + sway, groundY - 92, 5, 0, Math.PI * 2);
      ctx.fill();
    }

    // 5. Roots into Soil Layers
    ctx.strokeStyle = "rgba(229, 231, 235, 0.75)";
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(plantX, groundY);
    ctx.lineTo(plantX - 14, groundY + 28);
    ctx.moveTo(plantX, groundY);
    ctx.lineTo(plantX + 18, groundY + 34);
    ctx.moveTo(plantX, groundY);
    ctx.lineTo(plantX - 4, groundY + 54);
    ctx.stroke();

    requestAnimationFrame(renderBiome);
  }
  renderBiome();
}

// --- Multi-Model AI Inferences ---
function runInference() {
  const z = zones[state.activeZone];
  let effMoisture = state.moisture;
  let effTemp = state.temperature;
  let effVpd = state.vpd;
  let effNdvi = state.ndvi;

  if (state.injectStress) {
    effMoisture = Math.max(5.0, effMoisture - state.crashSeverity);
    effNdvi = Math.max(0.15, effNdvi - 0.12);
  }

  // 1. Random Forest Irrigation Probability
  const moistureZ = (20.0 - effMoisture) / 4.5;
  const rainZ = (3.0 - state.rain24h) / 4.0;
  const vpdZ = (effVpd - 1.5) / 0.8;
  const stageWeight = state.stage.includes("Flowering") ? 0.45 : 0.0;
  const score = 1.2 * moistureZ + 0.4 * rainZ + 0.2 * vpdZ + stageWeight;
  const rfProb = 1.0 / (1.0 + Math.exp(-score));
  const rfPred = rfProb >= 0.5 ? 1 : 0;
  const rfConf = Math.max(rfProb, 1.0 - rfProb);

  // 2. SVM Crop Stress Anomaly
  const anomScore = (effTemp > 31.0 ? 1.6 : 0.0) + (effMoisture < 19.0 ? 2.2 : 0.0) + (state.injectStress ? 2.5 : 0.0);
  const svmProb = 1.0 / (1.0 + Math.exp(-(anomScore - 1.2)));
  const svmPred = svmProb >= 0.5 ? 1 : 0;
  const svmConf = Math.max(svmProb, 1.0 - svmProb);

  // 3. LSTM 3-Day Trend Forecast & MC Uncertainty
  const lstmForecast = Math.max(7.5, effMoisture - 1.9 * (effVpd / 1.5) + (state.rain24h > 8 ? 4.5 : 0));
  const lstmUnc = 0.85 + (effTemp > 31.0 ? 0.6 : 0.1) + (state.injectStress ? 1.2 : 0.0);

  // 4. Prescriptive Action Calculations
  const targetMoist = 28.0;
  const deficit = Math.max(0, targetMoist - effMoisture);
  const waterReqMm = deficit * 2.8;
  const waterM3Ha = waterReqMm * 10.0;
  const pumpHours = waterM3Ha / 45.0;
  const energyKwh = waterM3Ha * 1.2;
  const co2Kg = energyKwh * 0.45;
  const costOffpeak = energyKwh * 0.08;

  // DOM Updates
  document.getElementById("val-moisture").innerText = effMoisture.toFixed(1) + "%";
  document.getElementById("val-temp").innerText = effTemp.toFixed(1) + "°C";
  document.getElementById("val-vpd").innerText = effVpd.toFixed(2) + " kPa";
  document.getElementById("val-ndvi").innerText = effNdvi.toFixed(2);
  document.getElementById("val-gdd").innerText = state.gdd + " °C-d";

  // Gauges Progress Bars
  document.getElementById("bar-moist").style.width = Math.min(100, Math.max(5, (effMoisture / 50) * 100)) + "%";
  document.getElementById("bar-temp").style.width = Math.min(100, Math.max(5, (effTemp / 48) * 100)) + "%";
  document.getElementById("bar-vpd").style.width = Math.min(100, Math.max(5, (effVpd / 3.5) * 100)) + "%";
  document.getElementById("bar-ndvi").style.width = (effNdvi * 100).toFixed(0) + "%";

  // RF Box
  const rfBadge = document.getElementById("rf-badge");
  const rfBar = document.getElementById("rf-bar");
  const rfConfText = document.getElementById("rf-conf-text");
  if (rfPred === 1) {
    rfBadge.className = "ai-badge badge-irrigate";
    rfBadge.innerText = "🚨 IRRIGATION REQUIRED";
  } else {
    rfBadge.className = "ai-badge badge-optimal";
    rfBadge.innerText = "✅ NO IRRIGATION NEEDED";
  }
  rfBar.style.width = (rfConf * 100).toFixed(0) + "%";
  rfConfText.innerText = `Tree-Vote Confidence: ${(rfConf * 100).toFixed(1)}%`;

  // SVM Box
  const svmBadge = document.getElementById("svm-badge");
  const svmBar = document.getElementById("svm-bar");
  const svmConfText = document.getElementById("svm-conf-text");
  if (svmPred === 1) {
    svmBadge.className = "ai-badge badge-stress";
    svmBadge.innerText = "🔴 STRESS ANOMALY DETECTED";
  } else {
    svmBadge.className = "ai-badge badge-normal";
    svmBadge.innerText = "🟢 CANOPY STATE NORMAL";
  }
  svmBar.style.width = (svmConf * 100).toFixed(0) + "%";
  svmConfText.innerText = `Platt-Scaled Confidence: ${(svmConf * 100).toFixed(1)}%`;

  // LSTM Box
  document.getElementById("lstm-val").innerText = `${lstmForecast.toFixed(1)}% ± ${lstmUnc.toFixed(2)}%`;
  const lstmBar = document.getElementById("lstm-bar");
  const lstmConfRatio = Math.max(0.2, 1.0 - lstmUnc / 6.0);
  lstmBar.style.width = (lstmConfRatio * 100).toFixed(0) + "%";
  document.getElementById("lstm-conf-text").innerText = `MC-Dropout Uncertainty: ±${lstmUnc.toFixed(2)}%`;

  // Prescriptive Directives
  document.getElementById("adv-water").innerText = `${waterReqMm.toFixed(1)} mm (${waterM3Ha.toFixed(1)} m³/ha)`;
  document.getElementById("adv-pump").innerText = `${pumpHours.toFixed(2)} hrs (${Math.round(pumpHours * 60)} mins)`;
  document.getElementById("adv-energy").innerText = `${energyKwh.toFixed(1)} kWh`;
  document.getElementById("adv-co2").innerText = `${co2Kg.toFixed(1)} kg CO₂e`;
  document.getElementById("adv-cost").innerText = `$${costOffpeak.toFixed(2)}`;

  // Update Spatial Tiles on HUD
  for (let zid = 1; zid <= 4; zid++) {
    const tileEl = document.getElementById(`tile-m-${zid}`);
    if (tileEl) {
      tileEl.innerText = zones[zid].baseMoist.toFixed(1) + "%";
    }
  }
}

// Select and Activate Zone
function selectZone(zId) {
  const z = zones[zId];
  if (!z) return;

  state.activeZone = zId;
  state.moisture = z.baseMoist;
  state.temperature = z.baseTemp;
  state.vpd = z.baseVpd;
  state.ndvi = z.baseNdvi;

  // Synchronize range sliders
  const sMoist = document.getElementById("slider-moist");
  const sTemp = document.getElementById("slider-temp");
  if (sMoist) sMoist.value = state.moisture;
  if (sTemp) sTemp.value = state.temperature;

  const lblMoist = document.getElementById("label-moist");
  const lblTemp = document.getElementById("label-temp");
  if (lblMoist) lblMoist.innerText = state.moisture.toFixed(1) + "%";
  if (lblTemp) lblTemp.innerText = state.temperature.toFixed(1) + "°C";

  // Update Zone Labels & Badges
  const activeLbl = document.getElementById("active-zone-label");
  if (activeLbl) activeLbl.innerText = z.name;

  const biomeBadge = document.getElementById("biome-zone-badge");
  if (biomeBadge) biomeBadge.innerText = z.badge;

  const biomeSoil = document.getElementById("biome-soil-type");
  if (biomeSoil) biomeSoil.innerHTML = `Soil: <strong>${z.soilDesc}</strong>`;

  const biomePri = document.getElementById("biome-priority");
  if (biomePri) biomePri.innerHTML = `Priority: <strong style="color:${z.priorityColor};">${z.priority}</strong>`;

  // Update Active UI States
  document.querySelectorAll(".zone-pill").forEach(p => {
    if (parseInt(p.getAttribute("data-zone")) === zId) {
      p.classList.add("active");
    } else {
      p.classList.remove("active");
    }
  });

  document.querySelectorAll(".zone-hud-tile").forEach(t => {
    if (t.id === `zone-tile-${zId}`) {
      t.classList.add("active");
    } else {
      t.classList.remove("active");
    }
  });

  // Flash highlight animation on dials
  document.querySelectorAll(".gauge-card").forEach(c => {
    c.classList.add("dial-flash");
    setTimeout(() => c.classList.remove("dial-flash"), 600);
  });

  playTone(480 + zId * 60, "sine", 0.12, 0.08);
  runInference();
}

// --- Interactive Handlers ---
function setupInteractions() {
  // Sound Toggle
  const soundBtn = document.getElementById("sound-btn");
  if (soundBtn) {
    soundBtn.addEventListener("click", () => {
      initAudio();
      state.soundEnabled = !state.soundEnabled;
      soundBtn.innerText = state.soundEnabled ? "🔊 Sound: ON" : "🔇 Sound: OFF";
      if (state.soundEnabled) playTone(520, "sine", 0.15, 0.1);
    });
  }

  // Sliders
  const sMoist = document.getElementById("slider-moist");
  if (sMoist) {
    sMoist.addEventListener("input", e => {
      state.moisture = parseFloat(e.target.value);
      document.getElementById("label-moist").innerText = state.moisture.toFixed(1) + "%";
      runInference();
    });
  }

  const sTemp = document.getElementById("slider-temp");
  if (sTemp) {
    sTemp.addEventListener("input", e => {
      state.temperature = parseFloat(e.target.value);
      state.vpd = 0.61078 * Math.exp((17.27 * state.temperature) / (state.temperature + 237.3)) * (1.0 - state.humidity / 100.0);
      document.getElementById("label-temp").innerText = state.temperature.toFixed(1) + "°C";
      runInference();
    });
  }

  const sRain = document.getElementById("slider-rain");
  if (sRain) {
    sRain.addEventListener("input", e => {
      state.rain24h = parseFloat(e.target.value);
      document.getElementById("label-rain").innerText = state.rain24h.toFixed(1) + " mm";
      if (state.rain24h > 10) playWaterDrop();
      runInference();
    });
  }

  const checkStress = document.getElementById("check-stress");
  if (checkStress) {
    checkStress.addEventListener("change", e => {
      state.injectStress = e.target.checked;
      if (state.injectStress) playTone(300, "sawtooth", 0.25, 0.1);
      runInference();
    });
  }

  // Scenario Presets
  const presets = {
    heatwave: { temp: 39.5, moist: 16.0, rain: 0.0, stress: false },
    monsoon: { temp: 23.0, moist: 38.0, rain: 32.0, stress: false },
    drought: { temp: 34.0, moist: 10.0, rain: 0.0, stress: true },
    flowering: { temp: 27.5, moist: 23.0, rain: 2.0, stress: false }
  };

  document.querySelectorAll(".preset-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const type = btn.getAttribute("data-preset");
      const p = presets[type];
      if (!p) return;
      state.temperature = p.temp;
      state.moisture = p.moist;
      state.rain24h = p.rain;
      state.injectStress = p.stress;
      state.vpd = 0.61078 * Math.exp((17.27 * state.temperature) / (state.temperature + 237.3)) * (1.0 - state.humidity / 100.0);

      if (sTemp) sTemp.value = p.temp;
      if (sMoist) sMoist.value = p.moist;
      if (sRain) sRain.value = p.rain;
      if (checkStress) checkStress.checked = p.stress;

      document.getElementById("label-temp").innerText = p.temp.toFixed(1) + "°C";
      document.getElementById("label-moist").innerText = p.moist.toFixed(1) + "%";
      document.getElementById("label-rain").innerText = p.rain.toFixed(1) + " mm";

      playTone(600, "triangle", 0.18, 0.09);
      runInference();
    });
  });

  // Wire Top Zone Pills
  document.querySelectorAll(".zone-pill").forEach(pill => {
    pill.addEventListener("click", () => {
      const zid = parseInt(pill.getAttribute("data-zone"));
      selectZone(zid);
    });
  });

  // Wire Bottom Spatial Zone Tiles
  for (let z = 1; z <= 4; z++) {
    const tile = document.getElementById(`zone-tile-${z}`);
    if (tile) {
      tile.addEventListener("click", () => {
        selectZone(z);
      });
    }
  }
}

// Initializer
document.addEventListener("DOMContentLoaded", () => {
  setupBgParticles();
  setupBiomeCanvas();
  setupInteractions();
  runInference();
});
